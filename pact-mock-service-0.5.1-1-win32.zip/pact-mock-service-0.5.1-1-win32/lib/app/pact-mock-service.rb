require 'pact/mock_service/cli'
Pact::MockService::CLI.start
