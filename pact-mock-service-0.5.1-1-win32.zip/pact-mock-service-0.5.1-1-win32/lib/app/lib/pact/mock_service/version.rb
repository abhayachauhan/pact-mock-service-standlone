module Pact
  module MockService
    VERSION = "0.5.1"
  end
end
