require 'pact/consumer/app_manager'
require 'pact/mock_service/app'
